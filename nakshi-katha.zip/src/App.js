import React, { useState } from "react";

function App() {
  const [lang, setLang] = useState("bn");

  const products = [
    { id: 1, name: { bn: "হাতে বানানো নকশী কাঁথা", en: "Handmade Nakshi Kantha" }, price: "৳1200" },
    { id: 2, name: { bn: "নকশী বালিশ কভার (২টি)", en: "Nakshi Pillow Cover (Set of 2)" }, price: "৳800" },
    { id: 3, name: { bn: "ফুলের নকশা করা বেডশিট", en: "Floral Embroidered Bed Sheet" }, price: "৳1500" }
  ];

  return (
    <div style={{ fontFamily: "sans-serif", padding: "20px" }}>
      <h1>{lang === "bn" ? "নকশী কাঁথা" : "Nakshi Kantha"}</h1>
      <button onClick={() => setLang(lang === "bn" ? "en" : "bn")}>
        {lang === "bn" ? "Switch to English" : "বাংলায় দেখুন"}
      </button>
      <div style={{ marginTop: "20px" }}>
        {products.map((p) => (
          <div key={p.id} style={{ border: "1px solid #ccc", margin: "10px", padding: "10px", borderRadius: "8px" }}>
            <h3>{p.name[lang]}</h3>
            <p>{p.price}</p>
            <button>{lang === "bn" ? "কার্টে যোগ করুন" : "Add to Cart"}</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;